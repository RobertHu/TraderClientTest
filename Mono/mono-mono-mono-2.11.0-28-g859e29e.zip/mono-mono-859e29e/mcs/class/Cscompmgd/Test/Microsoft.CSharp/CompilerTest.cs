//
// CompilerTest.cs
//
// Author:
//	Atsushi Enomoto <atsushi@ximian.com>
//
// (C) Ximian, Inc.
//

using System;
using Microsoft.CSharp;

using NUnit.Framework;

namespace MonoTests.Cscompmgd
{
	[TestFixture]
	public class CompilerTest
	{
		[SetUp]
		public void GetReady ()
		{
		}
	}
}
