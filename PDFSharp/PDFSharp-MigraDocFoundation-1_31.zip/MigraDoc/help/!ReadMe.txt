Help files for PDFsharp and MigraDoc can be downloaded separately.

We offer two versions:
 * a .CHM file for stand-alone use with the Windows Help Viewer
 * a Setup that integrates with the Visual Studio documentation (VS 2008 or VS 2005)

See http://www.pdfsharp.net/wiki/Help.ashx for further information.